<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Post</h2>
    <form action="<?php echo e(route('posts.update',$post->id); ?>"method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Title:</label><br>
        <input type="text" name="title" value="<?php echo e($post->title); ?>"required><br><br>

        <label>Content:</label><br>
        <textarea name="content" row="5" required><?php echo e($post->content); ?></textarea><br><br>

        <label>Category:</label><br>
        <select name="category_id" required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->); ?>" <?php echo e($post->category_id == $category->id? 'selected' : ''); ?>>
                <?php echo e($category->name); ?>

</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><br><br>
<button type="submit">Update</button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mi.tasks\project2_till.Auth\resources\views\posts\edit.blade.php ENDPATH**/ ?>