<?php $__env->startSection('content'); ?>

<div class="container">
<h2>MyPosts</h2>

<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div style="background: #f0f0f0; margin-bottom:20px; padding:10px;">
        <h3><?php echo e($post->title); ?></h3>
        <p><?php echo e($post->content); ?></p>
        <p><strong>Category:</strong><?php echo e($post->category->name); ?></p>
        <a href="<?php echo e(route('posts.edit',$post->id)); ?>" method="POST" style="display:inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit">Delete</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p>You have not created any osts yet..</p>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mi.tasks\project2_till.Auth\resources\views\posts\my-posts.blade.php ENDPATH**/ ?>