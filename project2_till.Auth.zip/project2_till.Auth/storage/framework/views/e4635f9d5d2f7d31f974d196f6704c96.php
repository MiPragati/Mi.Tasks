<div class="container">
    <h2>Create a New Post</h2>
    <form action="<?php echo e(route('posts.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label>Title:</label><br>
        <input type="text" name="title" required><br><br>

        <label>Content: </label><br>
        <select name="category_id" required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><br><br>

<button type="submit">Create</button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mi.tasks\project2_till.Auth\resources\views\posts\create.blade.php ENDPATH**/ ?>