<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function create(){
        $categories = Category::all();
        return view('posts.create',compact('caategories'));
    }

    public function store(Request $request){
        $request->validate([
        'title' => 'required',
        'content' => 'required',
        'category_id' =>'required|exists:categories,id'
        ]);

        Post::create([
            'title'=>$request->title,
            'content'=>$request->content,
            'category_id'=>$request->category_id,
            'user_id'=>Auth::id(),
        ]);

        return redirect()->route('profile')->with('success', 'Post Created!');
    }

    public function myPosts(){
        $posts = Auth::user()->posts()->with('category')->get();

        return view('posts.my-posts',compact('posts'));
    }

    public function edit($id){
        $post = Post::findOrFail($id);
        $categories = Category::all();

        if($post->user_id !== Auth::id()){
            abort(403);
        }
        return view('posts.edit',compact('post','categories'));
    }

    public function update(Request $request, $id){
        $post = Post::findOrFail($id);

        if($post->user_id !== Auth::id()){
            abord(403);
        }
        $post->update($request->only('title','content','category_id'));

        return redirect()->route('profile')->with('success','Post Updated!');
    }

    public function destroy($is){
        $post = Post::findOrFail($id);

        if($post->user_id !== Auth::id()){
            abort(403);
        }

        $post->delete();

        return redirect()->route('profile')->with('success','Post Deleted.');
    }


    public function index()
    {
        //
        $posts = Post::with('category')->get();
        return view('posts.index',compact('posts'));
    }

    public function postsByCategory($id)
    {
        $category = \App\Models\Category::findOrFail($id);
        $posts = $category->posts;

        return view('posts.by_category', compact('category','posts'));
    }

    public function show($id)
    {
        $post = \App\Models\Post::with('category')->findOrFail($id);
        return view('posts.show', compact('post'));
    }

}
