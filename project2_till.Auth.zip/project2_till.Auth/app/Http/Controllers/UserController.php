<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    //
    public function profile(){
        $user = Auth::user();
        $posts = Post::where('user-id', $user->id)->get();

        return view('profile', compact('user','posts'));
    }

    public function store(Request $request){
        $request->validate([
            'title'=>'required',
            'content'=>'required',
        ]);
        return redirect()->route('profile')->with('success', 'Post updated!');
    }
    public function destroy($id){
        $post = Post::findOrFail($id);
        $post->delete();
        return redirect()->route('profile')->with('success','Post deleted!');
    }
}
