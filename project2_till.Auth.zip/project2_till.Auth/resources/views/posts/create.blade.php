@extends('layouts.app')
<div class="container">
    <h2>Create a New Post</h2>
    <form action="{{route('posts.store')}}" method="post">
        @csrf
        <label>Title:</label><br>
        <input type="text" name="title" required><br><br>

        <label>Content: </label><br>
        <select name="category_id" required>
            @foreach($categories as $category)
            <option value="{{$category->id }}">{{$category->name}}</option>
            @endforeach
</select><br><br>

<button type="submit">Create</button>
</form>
</div>
@endsection
