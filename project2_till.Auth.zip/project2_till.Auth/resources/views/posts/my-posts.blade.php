@extends('layouts.app')

@section('content')

<div class="container">
<h2>MyPosts</h2>

@if(session('success'))
    <p style="color: green;">{{session('success')}}</p>
    @endif

    @forelse ($posts as $post)
    <div style="background: #f0f0f0; margin-bottom:20px; padding:10px;">
        <h3>{{$post->title}}</h3>
        <p>{{$post->content}}</p>
        <p><strong>Category:</strong>{{$post->category->name}}</p>
        <a href="{{route('posts.edit',$post->id)}}" method="POST" style="display:inline">
            @csrf
            @method('DELETE')
            <button type="submit">Delete</button>
</form>
@empty
<p>You have not created any osts yet..</p>
@endforelse
</div>
@endsection
