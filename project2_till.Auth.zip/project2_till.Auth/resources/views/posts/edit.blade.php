@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Edit Post</h2>
    <form action="{{route('posts.update',$post->id}}"method="POST">
        @csrf
        @method('PUT')

        <label>Title:</label><br>
        <input type="text" name="title" value="{{ $post->title}}"required><br><br>

        <label>Content:</label><br>
        <textarea name="content" row="5" required>{{$post->content}}</textarea><br><br>

        <label>Category:</label><br>
        <select name="category_id" required>
            @foreach($categories as $category)
            <option value="{{$category->}}" {{$post->category_id == $category->id? 'selected' : ''}}>
                {{$category->name}}
</option>
@endforeach
</select><br><br>
<button type="submit">Update</button>
</form>
</div>
@endsection
